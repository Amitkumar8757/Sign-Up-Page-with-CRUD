﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SignUp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignUp.Controllers
{
    public class SignUpController : Controller
    {
        private OurDbContext dbContext;

        public SignUpController( OurDbContext context)
        {
            dbContext = context;
        }
        public IActionResult Index()
        {
            var sip = dbContext.SignUps.ToList();
            return View(sip);
            
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create( SignUpModel singup)
        {
            if (ModelState.IsValid)
            { 
            dbContext.SignUps.Add(singup);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
            }
            else
            {
                return View(singup);
            }
        }

        public IActionResult Delete(int Id)
        {
            var sip = dbContext.SignUps.SingleOrDefault(r => r.Id == Id);
            if(sip!=null)
            {
                dbContext.SignUps.Remove(sip);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index");
            }
        }


            public IActionResult Edit(int Id)
            {
                var sip
                = dbContext.SignUps.SingleOrDefault(r => r.Id == Id);
                return View(sip);

            }
        [HttpPost]
        public IActionResult Edit(SignUpModel sip)
        {
            dbContext.Entry(sip).State = EntityState.Modified;
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
        
    }
}
